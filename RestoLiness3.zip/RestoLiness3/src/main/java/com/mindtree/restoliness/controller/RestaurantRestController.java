package com.mindtree.restoliness.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.restoliness.Exception.RestoLineWebProjectException;
import com.mindtree.restoliness.dto.ResponseBody;
import com.mindtree.restoliness.entity.Restaurant;
import com.mindtree.restoliness.service.RestaurantService;

@RestController
public class RestaurantRestController {
	@Autowired
	private RestaurantService restaurantService;

	@PostMapping("/addRestaurant")
	public ResponseEntity<?> addRestaurant(@RequestBody Restaurant restaurant) throws RestoLineWebProjectException {
		return new ResponseEntity<ResponseBody<Restaurant>>(new ResponseBody<Restaurant>(
				restaurantService.addRestaurant(restaurant), null, "Resturant Added Successfully", true), HttpStatus.OK);
	}
	
	@PutMapping("/restaurants/{restaurantId}")

	public ResponseEntity<?> updateName(@PathVariable int restaurantId ,@RequestBody Restaurant res)
			throws RestoLineWebProjectException {
		return new ResponseEntity<ResponseBody<Restaurant>>(
				new ResponseBody<Restaurant>(restaurantService.updateName(restaurantId ,res), null,
						"Resturant updated", true),
				HttpStatus.OK);
	}
}
