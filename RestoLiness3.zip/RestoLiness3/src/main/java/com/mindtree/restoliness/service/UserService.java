package com.mindtree.restoliness.service;

import java.util.Set;

import com.mindtree.restoliness.entity.User;

public interface UserService {

	boolean registerNewUser(User user);

	int credentialCheck(User user);

	Set<User> getAllUsers();

	User getUserById();

}
