package com.mindtree.restoliness.service.serviceimpl;

import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.restoliness.entity.Reservation;
import com.mindtree.restoliness.entity.Restaurant;
import com.mindtree.restoliness.entity.Status;
import com.mindtree.restoliness.entity.User;
import com.mindtree.restoliness.repository.ReservationRepository;
import com.mindtree.restoliness.repository.RestaurantRespository;
import com.mindtree.restoliness.repository.UserRepository;
import com.mindtree.restoliness.service.ReservationService;

@Service
public class ReservationServiceImpl implements ReservationService {

	@Autowired
	private RestaurantRespository restaurantRespository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ReservationRepository reservationRepository;

	@Override
	public int bookSeat(int noofseat, int restId, User userById) {

		Restaurant restaurant = restaurantRespository.findById(restId).get();
		int total = restaurant.getNoOfSeat();
		if (noofseat > 6) {
			return 0;
		} else if (total == 0) {
			return 1;
		} else if (noofseat > 2 && total == 2) {
			return 2;

		} else if (noofseat > total) {
			return 3;
		} else {
			double payment = noofseat * restaurant.getFee() + noofseat * restaurant.getExtraCharges();
			Reservation reservation = new Reservation();

			reservation.setUser(userById);
			reservation.setBookedSeat(noofseat);
			reservation.setPayment(payment);
			reservation.setStatus(Status.Reserved);
			int seatupdate = restaurant.getNoOfSeat() - noofseat;
			restaurant.setNoOfSeat(seatupdate);
			reservation.setRestaurant(restaurant);

			reservationRepository.save(reservation);
			return 4;
		}

	}

	@Override
	public Set<Reservation> getAllReservationOfUser(int userId) {

		return new TreeSet<Reservation>(userRepository.findById(userId).get().getReservation());
	}
	

	@Override
	public void cancelReservation(int reservationId) {
		Reservation reservation = reservationRepository.findById(reservationId).get();
		reservation.getStatus().equals(Status.Cancelled);
		
		Restaurant res = reservation.getRestaurant();
		res.setNoOfSeat(res.getNoOfSeat() + reservation.getBookedSeat());
		double payment = reservation.getPayment() - reservation.getPayment() * 0.4;
		reservation.setStatus(Status.Cancelled);
		reservation.setPayment(payment);
		 reservationRepository.save(reservation);

	}
	

}
