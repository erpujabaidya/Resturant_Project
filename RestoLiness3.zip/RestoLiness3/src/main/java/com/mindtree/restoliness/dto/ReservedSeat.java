package com.mindtree.restoliness.dto;

public class ReservedSeat {

	private int bookseat;

	public int getBookseat() {
		return bookseat;
	}

	public void setBookseat(int bookseat) {
		this.bookseat = bookseat;
	}

	public ReservedSeat() {
		// TODO Auto-generated constructor stub
	}

	public ReservedSeat(int bookseat) {
		this.bookseat = bookseat;
	}

}
