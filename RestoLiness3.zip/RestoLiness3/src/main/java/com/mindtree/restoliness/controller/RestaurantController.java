package com.mindtree.restoliness.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.mindtree.restoliness.dto.ResponseBody;

import com.mindtree.restoliness.Exception.RestoLineWebProjectException;
import com.mindtree.restoliness.entity.Restaurant;
import com.mindtree.restoliness.service.ReservationService;
import com.mindtree.restoliness.service.RestaurantService;
import com.mindtree.restoliness.service.UserService;

@Controller
public class RestaurantController {

	@Autowired
	private RestaurantService restaurantService;

	@Autowired
	private ReservationService reservationService;

	@Autowired
	private UserService userService;

	static int restaurantid;

	@RequestMapping("/restaurants")
	public String listRestaurant(Model model) {
		model.addAttribute("restaurantlist", restaurantService.listRestaurant());
		return "restaurantspage";
	}

	@RequestMapping(value = "booknow/{id}")
	public String reserved(@PathVariable int id, Model model) {
		restaurantid = id;

		model.addAttribute("restaurant", restaurantService.getRestaurantByID(id));

		return "bookseat";
	}

	@RequestMapping(value = "booknow/{id}/reserved", method = RequestMethod.POST)
	public String bookSeat(@ModelAttribute("noofseat") int noofseat) {

		int result = reservationService.bookSeat(noofseat, restaurantid, userService.getUserById());

		if (result == 0) {
			return "minseat";
		} else if (result == 1) {
			return "noseat";

		} else if (result == 2) {
			return "limitedseat";

		} else if (result == 3) {
			return "limitexceeds";
		} else {
			return "booked";
		}

	}

}
