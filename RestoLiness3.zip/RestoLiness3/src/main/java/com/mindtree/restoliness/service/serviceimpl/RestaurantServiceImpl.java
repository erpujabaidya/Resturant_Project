package com.mindtree.restoliness.service.serviceimpl;

import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.restoliness.Exception.service.RestoLineWebProjectServiceException;
import com.mindtree.restoliness.Exception.service.cutom.RestuarntAlreadyExistsException;
import com.mindtree.restoliness.Exception.service.cutom.ResturantNotFoundException;
import com.mindtree.restoliness.entity.Restaurant;
import com.mindtree.restoliness.repository.RestaurantRespository;
import com.mindtree.restoliness.service.RestaurantService;

@Service
public class RestaurantServiceImpl implements RestaurantService {

	@Autowired
	private RestaurantRespository restaurantRespository;

	@Override
	public Restaurant addRestaurant(Restaurant restaurant) throws RestoLineWebProjectServiceException {

		if (restaurantRespository.findByRestaurantName(restaurant.getRestaurantName()).isPresent())
			throw new RestuarntAlreadyExistsException("Restuarnt Already Exits");

		return restaurantRespository.save(restaurant);

	}

	@Override
	public Set<Restaurant> listRestaurant() {

		return new TreeSet<Restaurant>(restaurantRespository.findAll());
	}

	@Override
	public Restaurant getRestaurantByID(int resturantId) {

		return restaurantRespository.findById(resturantId).get();
	}

	@Override
	public Restaurant updateName(int restaurantId ,Restaurant res) throws NoSuchElementException {
		Restaurant h = restaurantRespository.findById(restaurantId)
				.orElseThrow(() -> new ResturantNotFoundException("Resturant Not Found"));
		h.setRestaurantId(restaurantId);
		h.setRestaurantName(res.getRestaurantName());
		h.setExtraCharges(res.getExtraCharges());
		h.setNoOfSeat(res.getNoOfSeat());
		h.setFee(res.getFee());
		h.setRevenue(res.getRevenue());
		return restaurantRespository.save(h);
		
		
	}

}
