package com.mindtree.restoliness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestoLineWebProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestoLineWebProjectApplication.class, args);
	}

}
