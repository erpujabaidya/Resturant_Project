package com.mindtree.restoliness.Exception.service.cutom;

import com.mindtree.restoliness.Exception.service.RestoLineWebProjectServiceException;

public class RestuarntAlreadyExistsException extends RestoLineWebProjectServiceException {

	private static final long serialVersionUID = -2433945051635693522L;

	public RestuarntAlreadyExistsException() {
		// TODO Auto-generated constructor stub
	}

	public RestuarntAlreadyExistsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public RestuarntAlreadyExistsException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public RestuarntAlreadyExistsException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public RestuarntAlreadyExistsException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
