package com.mindtree.restoliness.service.serviceimpl;

import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.restoliness.entity.User;
import com.mindtree.restoliness.repository.UserRepository;
import com.mindtree.restoliness.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	public static int userId;

	@Override
	public boolean registerNewUser(User user) {

		User users = userRepository.findByEmail(user.getEmail()).orElse(null);
		if (users != null)
			return false;

		userRepository.save(user);
		return true;

	}

	@Override
	public int credentialCheck(User user) {

		User users = userRepository.findByEmail(user.getEmail()).orElse(null);

		if (users == null)
			return 0;
		else {
			if (!users.getPassword().equals(user.getPassword())) {
				return 1;
			}

		}
		userId = users.getUserId();
		return 2;

	}

	@Override
	public Set<User> getAllUsers() {
		return new TreeSet<User>(userRepository.findAll().stream().collect(Collectors.toSet()));

	}

	@Override
	public User getUserById() {
		return userRepository.findById(getUserId()).get();
	}

	public static int getUserId() {
		return userId;
	}

}
