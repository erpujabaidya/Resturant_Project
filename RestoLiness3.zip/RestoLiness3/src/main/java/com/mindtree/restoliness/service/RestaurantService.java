package com.mindtree.restoliness.service;

import java.util.NoSuchElementException;
import java.util.Set;

import com.mindtree.restoliness.Exception.service.RestoLineWebProjectServiceException;
import com.mindtree.restoliness.entity.Restaurant;

public interface RestaurantService {

	Restaurant addRestaurant(Restaurant restaurant) throws RestoLineWebProjectServiceException;

	Set<Restaurant> listRestaurant();

	Restaurant getRestaurantByID(int id);

	//Restaurant updateName(int restaurantId, String restaurantName) throws NoSuchElementException ;

	Restaurant updateName(int restaurantId, Restaurant res);

	//Restaurant updateName(int restaurantId);

	

	

	

}
