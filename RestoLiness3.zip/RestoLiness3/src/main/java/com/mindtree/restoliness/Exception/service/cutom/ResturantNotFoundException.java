package com.mindtree.restoliness.Exception.service.cutom;

import java.util.NoSuchElementException;

public class ResturantNotFoundException extends NoSuchElementException {

	public ResturantNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public ResturantNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
