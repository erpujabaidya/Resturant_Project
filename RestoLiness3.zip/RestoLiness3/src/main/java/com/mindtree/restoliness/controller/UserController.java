package com.mindtree.restoliness.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.restoliness.entity.User;
import com.mindtree.restoliness.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/")
	public String slide() {
		return "slide";
	}

	

	@RequestMapping(value = "/get")
	public String indexpage() {
		return "welcome";
	}

	@RequestMapping(value = "/register")
	public String userHomePage(Model model) {

		model.addAttribute("users", new User());
		return "registrationpage";

	}

	@RequestMapping(value = "userregister", method = RequestMethod.POST)
	public String registerUser(@ModelAttribute("users") User user) {
		if (userService.registerNewUser(user)) {
			
			return "registersuccess";
		}
		return "registererror";
	}

	@RequestMapping(value = "/login")
	public String loginPage(Model model) {

		model.addAttribute("users", new User());
		return "loginpage";

	}
	
	@RequestMapping(value = "userlogin", method = RequestMethod.POST)
	public String loginUser(@ModelAttribute("users") User user,Model model) {

		int result = userService.credentialCheck(user);
		if (result == 0)
			return "errorlogin";
		else if (result == 1)
			return "errorpassword";
		else
			return "homepage";
	}

	@RequestMapping(value = "/homepage")
	public String homepage(Model model) {
		model.addAttribute("user", userService.getUserById());
		return "homepage";
	}

	@RequestMapping("/user")
	public String getAllUsers(Model model) {
		model.addAttribute("userlist", userService.getAllUsers());
		return "userhistory";
	}
	

}
