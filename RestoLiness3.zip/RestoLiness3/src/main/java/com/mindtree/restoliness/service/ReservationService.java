package com.mindtree.restoliness.service;

import java.util.Set;

import com.mindtree.restoliness.entity.Reservation;
import com.mindtree.restoliness.entity.User;

public interface ReservationService {

	int bookSeat(int noofseat, int restId, User userById);

	Set<Reservation> getAllReservationOfUser(int id);

	void cancelReservation(int reservationId);

	

	
	

} 
