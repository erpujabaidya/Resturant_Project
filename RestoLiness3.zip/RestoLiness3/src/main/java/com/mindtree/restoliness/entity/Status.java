package com.mindtree.restoliness.entity;

public enum Status {
	Reserved, Cancelled;
}
